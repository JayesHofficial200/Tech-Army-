from django.contrib import admin
from .models import FarmerProfile, CropUpload
from django.utils.html import format_html


@admin.register(FarmerProfile)
class FarmerProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'district', 'state', 'village')
    search_fields = ('user__username', 'district', 'village')


@admin.register(CropUpload)
class CropUploadAdmin(admin.ModelAdmin):
    list_display = (
        'crop_name',
        'predicted_crop',
        'health_percentage',
        'status',
        'farmer',
        'uploaded_at',
        'preview_image',
    )
    list_filter = ('uploaded_at', 'crop_name', 'status', 'predicted_crop')
    search_fields = ('crop_name', 'farmer__user__username', 'predicted_crop')
    readonly_fields = ('preview_image',)

    def preview_image(self, obj):
        if obj.image:
            return format_html('<img src="{}" width="100" height="100"/>', obj.image.url)
        return "No Image"
    preview_image.short_description = 'Image'
