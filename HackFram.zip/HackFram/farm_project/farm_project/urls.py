from django.contrib import admin
from django.urls import path
from django.contrib.auth import views as auth_views
from users import views

urlpatterns = [
    path('admin/', admin.site.urls),
    
    # public homepage
    path('', views.home, name='home'),

    # user panel (protected)
    path('user/', views.user_panel, name='user_panel'),

    path("register/", views.register, name="register"),

    # login/logout
    path('accounts/login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    path('accounts/logout/', auth_views.LogoutView.as_view(next_page='home'), name='logout'),

   
    # ... your existing URLs
    path('activity/', views.activity, name='activity'),
]
