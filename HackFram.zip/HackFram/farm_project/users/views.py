from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from .forms import CustomUserRegisterForm
from .models import FarmerProfile

# Public home page
def home(request):
    return render(request, 'home.html')


# Private user panel (after login/registration)
@login_required
def user_panel(request):
    return render(request, "user.html")


# Activity page
@login_required
def activity(request):
    return render(request, "activity.html")


# Registration page
def register(request):
    if request.method == "POST":
        form = CustomUserRegisterForm(request.POST)
        if form.is_valid():
            # Save User to auth_user
            user = form.save()

            # Create linked FarmerProfile with extra fields
            FarmerProfile.objects.create(
                user=user,
                full_name=form.cleaned_data.get("full_name"),
                age=form.cleaned_data.get("age"),
                dob=form.cleaned_data.get("dob"),
                gender=form.cleaned_data.get("gender"),
                state=form.cleaned_data.get("state"),
                district=form.cleaned_data.get("district"),
                village=form.cleaned_data.get("village"),
                location=form.cleaned_data.get("location"),
            )

            login(request, user)
            messages.success(request, "🎉 Registration successful! Welcome.")
            return redirect("user_panel")
    else:
        form = CustomUserRegisterForm()

    return render(request, "register.html", {"form": form})
