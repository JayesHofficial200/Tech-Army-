from django.db import models
from django.contrib.auth.models import User


class FarmerProfile(models.Model):
    GENDER_CHOICES = [
        ("M", "Male"),
        ("F", "Female"),
        ("O", "Other"),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE)
    full_name = models.CharField(max_length=150)
    age = models.PositiveIntegerField(null=True, blank=True)
    dob = models.DateField(null=True, blank=True)
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES, null=True, blank=True)

    state = models.CharField(max_length=100, null=True, blank=True)
    district = models.CharField(max_length=100, null=True, blank=True)
    village = models.CharField(max_length=100, null=True, blank=True)
    location = models.CharField(max_length=255, null=True, blank=True)  # live location

    def __str__(self):
        return self.full_name or self.user.username


class CropUpload(models.Model):
    farmer = models.ForeignKey(FarmerProfile, on_delete=models.CASCADE)
    crop_name = models.CharField(max_length=100, blank=True, null=True)  # user can choose or leave blank
    image = models.ImageField(upload_to="crop_images/")
    uploaded_at = models.DateTimeField(auto_now_add=True)

    # new fields to store prediction result
    predicted_crop = models.CharField(max_length=100, blank=True, null=True)
    health_percentage = models.FloatField(blank=True, null=True)

    status = models.CharField(
        max_length=50,
        choices=[("Pending", "Pending"), ("Top 3", "Top 3"), ("Not Selected", "Not Selected")],
        default="Pending",
    )

    def __str__(self):
        return f"{self.crop_name or 'Unknown'} by {self.farmer.user.username}"
