# users/forms.py
from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm

class CustomUserRegisterForm(UserCreationForm):
    full_name = forms.CharField(max_length=200, required=True)
    age = forms.IntegerField(required=True)
    dob = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))
    gender = forms.ChoiceField(choices=[('M', 'Male'), ('F', 'Female'), ('O', 'Other')])
    state = forms.CharField(max_length=100, required=False)
    district = forms.CharField(max_length=100, required=False)
    village = forms.CharField(max_length=100, required=False)
    location = forms.CharField(widget=forms.Textarea, required=False)

    class Meta:
        model = User
        fields = ['username', 'password1', 'password2']  # ✅ Only User fields here
